describe('example tests', function() {
    it('should handle the obvious', function() {
        false.should.equal(false);
    });

    it('can\'t handle the truth', function() {
        true.should.equal(false);
    });
});
